<?php
	
	/**
	 * Created by PhpStorm.
	 * User: tci_mi
	 * Date: 16/10/26
	 * Time: 上午10:14
	 */
	return [
		'My Company'=>'崇光科技',
		'Home'=>'主页',
		'About'=>'关于',
		'Contact'=>'联系我们',
		'Signup'=>'注销',
		'Login'=>'登录',
	];